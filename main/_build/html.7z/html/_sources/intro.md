# Introducción

¡Hola!,

En Celsia nos encanta acompañarte en la meta de ser más eficientes, por eso te presentamos tu informe de consumo de energía correspondiente al mes anterior.





![alt text](https://www.celsia.com/wp-content/uploads/2021/11/Celsia-Horizonal-Eslogan_Jpg.jpg)